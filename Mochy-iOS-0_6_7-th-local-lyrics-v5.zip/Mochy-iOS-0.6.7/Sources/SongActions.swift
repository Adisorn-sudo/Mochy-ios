import UIKit

/// Menu thao tác cho một bài hát (phát tiếp, hàng đợi, yêu thích, playlist, tải xuống).
enum SongActions {
    static func present(for song: Song, from vc: UIViewController, sourceView: UIView? = nil,
                        removeTitle: String? = nil, onRemove: (() -> Void)? = nil) {
        let sheet = UIAlertController(title: song.title, message: song.artist, preferredStyle: .actionSheet)
        let player = PlayerEngine.shared
        let library = Library.shared

        sheet.addAction(UIAlertAction(title: L("Phát tiếp theo"), style: .default) { _ in
            player.playNext(song)
            Toast.show(L("Sẽ phát tiếp theo"))
        })
        sheet.addAction(UIAlertAction(title: L("Thêm vào hàng đợi"), style: .default) { _ in
            player.addToQueue(song)
            Toast.show(L("Đã thêm vào hàng đợi"))
        })
        let liked = library.isLiked(song)
        sheet.addAction(UIAlertAction(title: liked ? L("Bỏ yêu thích") : L("Thêm vào Yêu thích"), style: .default) { _ in
            let nowLiked = library.toggleLike(song)
            LastFM.shared.love(song, loved: nowLiked)
            Toast.show(nowLiked ? L("Đã thêm vào Yêu thích") : L("Đã bỏ khỏi Yêu thích"))
        })
        if let artistId = song.artistId, !artistId.isEmpty {
            sheet.addAction(UIAlertAction(title: L("Xem nghệ sĩ"), style: .default) { _ in
                MusicPageViewController.present(artist: song.artist, id: artistId, from: vc)
            })
        }
        sheet.addAction(UIAlertAction(title: L("Thêm vào playlist…"), style: .default) { _ in
            presentPlaylistPicker(for: song, from: vc, sourceView: sourceView)
        })

        let manager = DownloadManager.shared
        if song.isLocalFile {
            sheet.addAction(UIAlertAction(title: L("Xoá khỏi nhạc trong máy"), style: .destructive) { _ in
                if PlayerEngine.shared.currentSong == song { PlayerEngine.shared.clear() }
                library.removeLocalTrack(id: song.videoId)
                Toast.show(L("Đã xoá bài khỏi máy"))
            })
        } else if library.isDownloaded(song) {
            sheet.addAction(UIAlertAction(title: L("Xoá bản tải xuống"), style: .destructive) { _ in
                library.removeDownload(song)
                Toast.show(L("Đã xoá bản tải"))
            })
        } else if manager.isActive(song.videoId) {
            sheet.addAction(UIAlertAction(title: L("Huỷ tải xuống"), style: .destructive) { _ in
                manager.cancel(song.videoId)
            })
        } else {
            sheet.addAction(UIAlertAction(title: L("Tải xuống để nghe offline"), style: .default) { _ in
                manager.start(song)
                Toast.show(L("Đang tải xuống…"))
            })
        }
        sheet.addAction(UIAlertAction(title: L("Đổi ảnh bìa…"), style: .default) { _ in
            CustomArtworkPicker.present(for: song, from: vc)
        })
        sheet.addAction(UIAlertAction(title: L("Tạo / sửa lời bài hát…"), style: .default) { _ in
            CustomLyricsEditorViewController.present(for: song, from: vc)
        })
        if let removeTitle = removeTitle, let onRemove = onRemove {
            sheet.addAction(UIAlertAction(title: removeTitle, style: .destructive) { _ in onRemove() })
        }
        sheet.addAction(UIAlertAction(title: L("Đóng"), style: .cancel, handler: nil))
        anchor(sheet, in: vc, sourceView: sourceView)
        vc.present(sheet, animated: true, completion: nil)
    }

    static func presentPlaylistPicker(for song: Song, from vc: UIViewController, sourceView: UIView? = nil) {
        let sheet = UIAlertController(title: L("Thêm vào playlist"), message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: L("Playlist mới…"), style: .default) { _ in
            promptNewPlaylist(from: vc) { name in
                let list = Library.shared.createPlaylist(name: name, with: song)
                Toast.show(LF("Đã tạo \"%@\"", "\(list.name)"))
            }
        })
        for list in Library.shared.playlists {
            sheet.addAction(UIAlertAction(title: list.name, style: .default) { _ in
                if Library.shared.add(song, toPlaylist: list.id) {
                    Toast.show(LF("Đã thêm vào \"%@\"", "\(list.name)"))
                } else {
                    Toast.show(LF("Bài này đã có trong \"%@\"", "\(list.name)"))
                }
            })
        }
        sheet.addAction(UIAlertAction(title: L("Đóng"), style: .cancel, handler: nil))
        anchor(sheet, in: vc, sourceView: sourceView)
        vc.present(sheet, animated: true, completion: nil)
    }

    static func promptNewPlaylist(from vc: UIViewController, initial: String = "", title: String = L("Playlist mới"),
                                  confirm: String = L("Tạo"), _ done: @escaping (String) -> Void) {
        let alert = UIAlertController(title: title, message: L("Đặt tên cho playlist"), preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = L("Tên playlist")
            field.text = initial
            field.autocapitalizationType = .sentences
        }
        alert.addAction(UIAlertAction(title: L("Huỷ"), style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: confirm, style: .default) { _ in
            done(alert.textFields?.first?.text ?? "")
        })
        vc.present(alert, animated: true, completion: nil)
    }

    private static func anchor(_ sheet: UIAlertController, in vc: UIViewController, sourceView: UIView?) {
        if let popover = sheet.popoverPresentationController {
            let source = sourceView ?? vc.view!
            popover.sourceView = source
            popover.sourceRect = sourceView == nil
                ? CGRect(x: source.bounds.midX, y: source.bounds.midY, width: 1, height: 1)
                : source.bounds
        }
    }
}
